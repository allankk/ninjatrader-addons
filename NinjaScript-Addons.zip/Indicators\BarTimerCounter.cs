// 
// Copyright (C) 2017, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Forms;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	// changelog:  V1.1 fixed serialization for TextColor
	// changelog:  V1.2 Fixed serialization for timespan
	// changelog:  V1.3 Added Volumetric bars support, minor code optimization
	
	[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1001:TypesThatOwnDisposableFieldsShouldBeDisposable")]
	public class BarTimerCounter : Indicator
	{	
		private string			timeLeft	= string.Empty;
		private DateTime		now		 	= Core.Globals.Now;
		private bool			connected,	hasRealtimeData, timeFlag = false;
		private SessionIterator sessionIterator;
		private System.Windows.Threading.DispatcherTimer timer;
		private long 			volume;
		private TimeSpan 		TChkLevel;	
		private int 			barType, lastBar, lastVBar, lastTKBar, ChkLevel;
		private	Gui.Tools.SimpleFont textFont;
		private TimeSpan timeAlertLevel;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{				
				Description 		= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionBarTimer;
				Name 				= "BarTimerCounter v1.3";
				Calculate			= Calculate.OnEachTick;
				DrawOnPricePanel	= false;
				IsChartOnly			= true;
				IsOverlay			= true;
				DisplayInDataBox	= false;				
				textFont			= new Gui.Tools.SimpleFont("Arial", 11);
				SoundsOn			= false;				
				UpSoundFile			= @"C:\Program Files (x86)\NinjaTrader 8\sounds\Alert2.Wav";
				myTextBox			= TextPosition.BottomRight;
				TextAlertColor		= Brushes.Red;
				TextAlertBackColor	= Brushes.Yellow;	
				SetTickAlert		= false;
				SetTimeAlert		= false;
				SetVolumeAlert		= false;
				VolumeAlertLevel	= 100;
				ShowText			= true;
				TimeAlertLevel		= TimeSpan.Parse("00:00:10");
				TickAlertLevel		= 100;
				TextColor 			= Brushes.White;
			}
			else if (State == State.DataLoaded)
			{
				// determine bar type first.
				
				if ((BarsPeriod.BarsPeriodType == BarsPeriodType.Tick 
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Tick)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Tick)))
				{
					barType = 1;  // tick counter needed
					
					if (SetTickAlert)
					{
						ChkLevel = (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi
								|| BarsPeriod.BarsPeriodType == BarsPeriodType.LineBreak
								|| BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric)
								? BarsPeriod.BaseBarsPeriodValue : BarsPeriod.Value;	
	
						if (TickAlertLevel > ChkLevel)  // reset alert level to bar ticks if exceeds tick in bar.
						{
							TickAlertLevel = ChkLevel;
							Print ("BarTimerCounter: Alert setting exceeds ticks in bar, setting alert level to be same as bar ticks: "+ChkLevel);
							Log("BarTimerCounter: Alert setting exceeds ticks in bar, setting alert level to be same as bar ticks: "+ChkLevel, LogLevel.Warning);
						}	
					}
				}
				
				else if ((BarsPeriod.BarsPeriodType == BarsPeriodType.Volume 
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Volume)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Volume)))
				{
					barType = 2;  // Volume counter counter needed
					
					if (SetVolumeAlert)
					{
					
						ChkLevel = (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Volume
									|| BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Volume) 
									? BarsPeriod.BaseBarsPeriodValue : BarsPeriod.Value;	
					
						if (VolumeAlertLevel > ChkLevel)  // reset alert level to bar volume if exceeds volume in bar.
						{
							VolumeAlertLevel = ChkLevel;
							Print ("BarTimerCounter: Alert setting exceeds volume in bar, setting alert level to be same as bar volume: "+ChkLevel);
							Log("BarTimerCounter: Alert setting exceeds volume in bar, setting alert level to be same as bar volume: "+ChkLevel, LogLevel.Warning);
						}
					}
				}
				else if ((BarsPeriod.BarsPeriodType == BarsPeriodType.Minute 
					|| BarsPeriod.BarsPeriodType == BarsPeriodType.Second 
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Minute) 
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Second)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.LineBreak && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Minute) 
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.LineBreak && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Second)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Minute)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Second)))
				{
					barType = 3;  // time based bar timer needed	
					
					ChkLevel = (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi 
								|| BarsPeriod.BarsPeriodType == BarsPeriodType.LineBreak
								|| BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric)  
								? BarsPeriod.BaseBarsPeriodValue : BarsPeriod.Value;
					
					if ((BarsPeriod.BarsPeriodType == BarsPeriodType.Minute 
						|| BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Minute
						|| BarsPeriod.BarsPeriodType == BarsPeriodType.LineBreak && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Minute)
						|| BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Minute)
						ChkLevel = ChkLevel * 60;
					
					if (SetTimeAlert)
					{
					
						if (TimeAlertLevel.TotalSeconds > ChkLevel)  // reset alert level to default time alert if exceeds time of bar.
						{
							TimeAlertLevel = TimeSpan.Parse("00:00:10");
							Print ("BarTimerCounter: Alert setting exceeds time of bar, setting alert level to 10 seconds ");
							Log("BarTimerCounter: Alert setting exceeds time of bar, setting alert level to 10 seconds ", LogLevel.Warning);
						}
					}
				}
				else 
				{
					barType = 4;
					Draw.TextFixed(this, "NinjaScriptInfo", "BarTimerCounter, please use On Minute, fixed Tick or fixed Volume bars", myTextBox);
				}
			}
			else if (State == State.Realtime)
			{
				if (barType != 3) return; // only process this section for time based bar timer
				
				if (timer == null)
				{
					if (Bars.BarsType.IsTimeBased && Bars.BarsType.IsIntraday)
					{
						lock (Connection.Connections)
						{
							if (Connection.Connections.ToList().FirstOrDefault(c => c.Status == ConnectionStatus.Connected 
								&& c.InstrumentTypes.Contains(Instrument.MasterInstrument.InstrumentType)) == null)
								Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.BarTimerDisconnectedError, myTextBox);
							else
							{
								if (!SessionIterator.IsInSession(Now, false, true))
									Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.BarTimerSessionTimeError, myTextBox, 
									TextColor, TextFont, Brushes.Transparent, Brushes.Transparent, 0);
								else
									Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.BarTimerWaitingOnDataError, myTextBox, 
									TextColor, TextFont, Brushes.Transparent, Brushes.Transparent, 0);
							}
						}
					}
					else
						Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.BarTimerTimeBasedError, myTextBox);
				}
			}
			else if (State == State.Terminated)
			{
				if (timer == null)
					return;

				timer.IsEnabled = false;
				timer = null;
			}
		}

		protected override void OnBarUpdate()
		{				
			if (barType == 4) return;  // invalid bar type (Renko, range, etc.)
			
//			=========== Timer =================
			
			if (barType == 3 && State == State.Realtime ) // bar timer code
			{
				hasRealtimeData = true;
				connected = true;
				return;
			}
			
//			========== Volume ===============	
			if (barType == 2)
			{
				volume = (long)Volume[0];
				
				double volumeCount =  ((BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi || BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric)
					? BarsPeriod.BaseBarsPeriodValue - volume : BarsPeriod.Value - volume) ;    //BarsPeriod.BaseBarsPeriodValue

				string volume1 = (ShowText ? NinjaTrader.Custom.Resource.VolumeCounterVolumeRemaining + volumeCount +  "": volumeCount +  "");
				
				if (SetVolumeAlert && volumeCount <= VolumeAlertLevel )
				{
					if (CurrentBar != lastVBar)  // playsound once per bar
					{
						lastVBar = CurrentBar;
						if (SoundsOn)
							PlaySound(UpSoundFile);
					}
					RemoveDrawObject ("NinjaScriptInfo");
					Draw.TextFixed (this,"NinjaScriptInfo1", volume1, myTextBox, TextAlertColor, TextFont, Brushes.Transparent, TextAlertBackColor, 100);
				}
				else
				{
					RemoveDrawObject ("NinjaScriptInfo1");
					Draw.TextFixed(this, "NinjaScriptInfo", volume1, myTextBox, TextColor, TextFont, Brushes.Transparent, Brushes.Transparent, 0);  //ChartControl.Properties.AxisPen.Brush
				}						
			}
			
			
//			================TICK======================
			
			if (barType == 1)
			{
				double periodValue = (BarsPeriod.BarsPeriodType == BarsPeriodType.Tick) ? BarsPeriod.Value : BarsPeriod.BaseBarsPeriodValue;
				double tickCount =   periodValue - Bars.TickCount;
				string tick1 = (ShowText ? "Ticks Remaining = "+tickCount : tickCount.ToString());
								
				if (SetTickAlert && tickCount <= TickAlertLevel)
				{
					if (CurrentBar != lastTKBar)  // playsound once per bar
					{
						lastTKBar = CurrentBar;
						if (SoundsOn)
							PlaySound(UpSoundFile);
					}
					RemoveDrawObject ("NinjaScriptInfo");
					Draw.TextFixed (this,"NinjaScriptInfo1", tick1, myTextBox, TextAlertColor, TextFont, Brushes.Transparent, TextAlertBackColor, 100);
				}
				else
				{
					RemoveDrawObject ("NinjaScriptInfo1");
					Draw.TextFixed(this, "NinjaScriptInfo", tick1, myTextBox, TextColor, TextFont, Brushes.Transparent, Brushes.Transparent, 0);  //ChartControl.Properties.AxisPen.Brush
				}			
			}  // tick counter end
		}
	
		#region Properties
		
		[Display(ResourceType = typeof (Custom.Resource), Name = "Display Text 'xxx Remaining =' ", Description="Show Volume/Ticks/Time Remainging = text", Order = 5, GroupName = "Display")]
		public bool ShowText
		{ get; set; }	
		
		[Display(ResourceType = typeof (Custom.Resource), Name = "Enable Tick Alert", Order = 6, GroupName = "Alerts")]
		public bool SetTickAlert
		{ get; set; }	
		
		[Display(ResourceType = typeof (Custom.Resource), Name = "Enable Time Alert", Order = 8, GroupName = "Alerts")]
		public bool SetTimeAlert
		{ get; set; }
		
		[Display(ResourceType = typeof (Custom.Resource), Name = "Enable Volume Alert", Order = 10, GroupName = "Alerts")]
		public bool SetVolumeAlert
		{ get; set; }	
				
		[Display(ResourceType = typeof (Custom.Resource), Name = "Time Alert level", Order = 9, GroupName = "Alerts")]
		public TimeSpan TimeAlertLevel
		{
			get {return timeAlertLevel;}
		 	set {timeAlertLevel = value; }
		}		
		[Browsable(false)]
		public string timeAlertLevelSerialize
        {
            get { return timeAlertLevel.ToString(); }
            set { timeAlertLevel = TimeSpan.Parse(value); }
        }
				
		
		[Range (1, int.MaxValue)]
		[Display(ResourceType = typeof (Custom.Resource), Name = "Tick Alert level", Order = 7, GroupName = "Alerts")]
		public int TickAlertLevel
		{ get; set; }	
		
		[Range (1, int.MaxValue)]
		[Display(ResourceType = typeof (Custom.Resource), Name = "Volume Alert level", Order = 11, GroupName = "Alerts")]
		public int VolumeAlertLevel
		{ get; set; }	
				
		
		[Display(Name="Sound Alert", Description="Play sounds one first alert", Order=12, GroupName="Alerts")]
		public bool SoundsOn
		{ get; set; }			
		
		[Display(Name="Alert sound file", Description="Enter sound file path/name", Order=13, GroupName="Alerts")]
		[PropertyEditor("NinjaTrader.Gui.Tools.FilePathPicker", Filter="Wav Files (*.wav)|*.wav")]
		public string UpSoundFile
		{ get; set; }	
		
		[Display(Name="Text box location", Description="Select text location", Order=1, GroupName="Display")]
		public TextPosition myTextBox
		{ get; set; }		
		
	
		[Display(Name = "Text Font", Description= "Select font, style, size to display on chart", GroupName= "Display", Order= 2)]
		public Gui.Tools.SimpleFont TextFont
		{
			get { return textFont; }
			set { textFont = value; }
		}
		
		[XmlIgnore]
		[Display(Name="Text Color", Description="Standard text color", Order=3, GroupName="Display")]
		public System.Windows.Media.Brush TextColor
		{ get; set; }	
		
		[Browsable(false)]
		public string TextColorSerializable
		{
			get { return Serialize.BrushToString(TextColor); }
			set { TextColor = Serialize.StringToBrush(value); }
		}		
		
		[XmlIgnore]
		[Display(Name="Alert text color", Description="Text color when alerting", Order=4, GroupName="Display")]
		public System.Windows.Media.Brush TextAlertColor
		{ get; set; }

		[Browsable(false)]
		public string TextAlertColorSerializable
		{
			get { return Serialize.BrushToString(TextAlertColor); }
			set { TextAlertColor = Serialize.StringToBrush(value); }
		}	
		
		[XmlIgnore]
		[Display(Name="Alert text Background", Description="Background color when alerting", Order=5, GroupName="Display")]
		public System.Windows.Media.Brush TextAlertBackColor
		{ get; set; }

		[Browsable(false)]
		public string TextAlertBackColorSerializable
		{
			get { return Serialize.BrushToString(TextAlertBackColor); }
			set { TextAlertBackColor = Serialize.StringToBrush(value); }
		}					

		#endregion
		
		
		
		#region BarTimer code
		
		protected override void OnConnectionStatusUpdate(ConnectionStatusEventArgs connectionStatusUpdate)
		{
			if (connectionStatusUpdate.PriceStatus == ConnectionStatus.Connected
				&& connectionStatusUpdate.Connection.InstrumentTypes.Contains(Instrument.MasterInstrument.InstrumentType)
				&& Bars.BarsType.IsTimeBased
				&& Bars.BarsType.IsIntraday)
			{
				connected = true;
				
				if (DisplayTime() && timer == null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						timer			= new System.Windows.Threading.DispatcherTimer { Interval = new TimeSpan(0, 0, 1), IsEnabled = true };
						timer.Tick		+= OnTimerTick;
					});
				}
			}
			else if (connectionStatusUpdate.PriceStatus == ConnectionStatus.Disconnected)
				connected = false;
		}

		private bool DisplayTime()
		{
			return ChartControl != null
					&& Bars != null
					&& Bars.Instrument.MarketData != null;
		}
		
		private void OnTimerTick(object sender, EventArgs e)
		{
			ForceRefresh();
			
			if (DisplayTime())
			{
				if (timer != null && !timer.IsEnabled)
					timer.IsEnabled = true;
				
				if (connected)
				{
					if (SessionIterator.IsInSession(Now, false, true))
					{
						if (hasRealtimeData)
						{
							TimeSpan barTimeLeft = Bars.GetTime(Bars.Count - 1).Subtract(Now);
												
							timeLeft = (barTimeLeft.Ticks < 0 ? "00:00:00" : barTimeLeft.Hours.ToString("00") + ":" + barTimeLeft.Minutes.ToString("00") + ":" + barTimeLeft.Seconds.ToString("00"));
							
							if (SetTimeAlert && !timeFlag && barTimeLeft.TotalSeconds <= TimeAlertLevel.TotalSeconds)
							{
								if (CurrentBar != lastBar)  // playsound once per bar
								{
									timeFlag = true;
									lastBar = CurrentBar;
									if (SoundsOn)
										PlaySound(UpSoundFile);
								}
							}

							if (lastBar != CurrentBar || barTimeLeft.TotalSeconds <= 0)
							{
								timeFlag = false; // reset on new bar
							}


							if (timeFlag)
							{
								RemoveDrawObject ("NinjaScriptInfo");
								Draw.TextFixed (this,"NinjaScriptInfo1", (ShowText ? NinjaTrader.Custom.Resource.BarTimerTimeRemaining + timeLeft : timeLeft), 
									myTextBox, TextAlertColor, TextFont, Brushes.Transparent, TextAlertBackColor, 100);	
							}
							else
							{
								RemoveDrawObject ("NinjaScriptInfo1");
								Draw.TextFixed(this, "NinjaScriptInfo", (ShowText ? NinjaTrader.Custom.Resource.BarTimerTimeRemaining + timeLeft : timeLeft) , 
									myTextBox, TextColor, TextFont, Brushes.Transparent, Brushes.Transparent, 0);
							}							
						} 
						else
							Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.BarTimerWaitingOnDataError, 
							myTextBox, TextColor, TextFont, Brushes.Transparent, Brushes.Transparent, 0);
					}
					else
						Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.BarTimerSessionTimeError, 
						myTextBox, TextColor, TextFont, Brushes.Transparent, Brushes.Transparent, 0);
				}
				else
				{
					Draw.TextFixed(this, "NinjaScriptInfo", NinjaTrader.Custom.Resource.BarTimerDisconnectedError, 
						myTextBox, TextColor, TextFont, Brushes.Transparent, Brushes.Transparent, 0);
					
					if (timer != null)
						timer.IsEnabled = false;
				}
			}
		}

		private SessionIterator SessionIterator
		{
			get 
			{
				if (sessionIterator == null)
					sessionIterator = new SessionIterator(Bars);
				return sessionIterator;
			}
		}

		private DateTime Now
		{
			get
			{
				now = (Cbi.Connection.PlaybackConnection != null ? Cbi.Connection.PlaybackConnection.Now : Core.Globals.Now);

				if (now.Millisecond > 0)
					now = Core.Globals.MinDate.AddSeconds((long)Math.Floor(now.Subtract(Core.Globals.MinDate).TotalSeconds));

				return now;
			}
		}
		#endregion
		
	} // public class BarTimerCounter
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BarTimerCounter[] cacheBarTimerCounter;
		public BarTimerCounter BarTimerCounter()
		{
			return BarTimerCounter(Input);
		}

		public BarTimerCounter BarTimerCounter(ISeries<double> input)
		{
			if (cacheBarTimerCounter != null)
				for (int idx = 0; idx < cacheBarTimerCounter.Length; idx++)
					if (cacheBarTimerCounter[idx] != null &&  cacheBarTimerCounter[idx].EqualsInput(input))
						return cacheBarTimerCounter[idx];
			return CacheIndicator<BarTimerCounter>(new BarTimerCounter(), input, ref cacheBarTimerCounter);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BarTimerCounter BarTimerCounter()
		{
			return indicator.BarTimerCounter(Input);
		}

		public Indicators.BarTimerCounter BarTimerCounter(ISeries<double> input )
		{
			return indicator.BarTimerCounter(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BarTimerCounter BarTimerCounter()
		{
			return indicator.BarTimerCounter(Input);
		}

		public Indicators.BarTimerCounter BarTimerCounter(ISeries<double> input )
		{
			return indicator.BarTimerCounter(input);
		}
	}
}

#endregion
